<?php
define('DBHOST',"localhost");
define('DBUSER',"mysql");
define('DBPASSWORD',"mysql");
define('DBNAME',"tva");
define('DR', "http://tva.eo");
define('APPNAME', "TVA");
define('URL', "http://lifepc.uz");

// $db=mysqli_connect(DBHOST, DBUSER, DBPASSWORD, DBNAME) or die("DB Connection Error");
