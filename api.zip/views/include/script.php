	<script src="<?=DR?>/assets/js/popper.min.js"></script>
	<script src="<?=DR?>/assets/js/bootstrap.min.js"></script>
	<script src="<?=DR?>/assets/js/main.js"></script>
	<!-- The javascript plugin to display page loading on top-->
	<script src="<?=DR?>/assets/js/plugins/pace.min.js"></script>
	<!-- Page specific javascripts-->
