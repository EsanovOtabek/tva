Tizimning asosiy funktsional xususiyatlari: 

1.Web sayt ko'rinishida tadbir  ma'lumotlarini kiritish (ma'ruza nomi, ma'ruzachi, vaqti, joyi, )  Foydalanuvchini ro'yxatdan o'tkazish, fayllarni yuklash (ovoz, matn, video) va tashqi manbalarga havolalar. 

2. Yaratilgan tadbir sahifasiga audio yoki video faylni yuklash, keyinchalik uni matnga aylantirish (transkribatsiya). Agar videofayl yuklangan bo'lsa (yoki unga havola), unda qo'shimcha manipulyatsiyaga videodan audio trekni ajratish va bundan keyin faqat u bilan ishlash kiradi. 

3. Mazmunga ega bo'lmagan so'zlardan (masalan, so'z-parazitlar, "eee" va hokazo) matnni tozalash qobiliyati. 

4. Olingan matn asosida konspektni hosil qilish Xulosa matni va so'zlar buluti(havolasi mavjud bo'lgan kalit so'zlar to'plami)ni shakllantirish. 

5. Tizim admini foydalanuvchilar uchun fayllarga kirish huquqlarini sozlash imkoniyatiga ega. Shu bilan birga, foydalanuvchilar xohishiga ko'ra nutqning qisqacha mazmuni yoki uning to'liq matnidan foydalanishlari mumkin. 

6. LMS Moodle bilan integratsiya imkoniyati (ta'lim muassasalarida foydalanish uchun).




От Sarvar Abdullaev всем:  05:21 PM
LSA - Latent Semantic Analysis
TextRank
LexRank
Luhn
gensim
BART Transformers
https://www.amazon.com/Artificial-Intelligence-Modern-Approach-Global/dp/1292153962

22-bob 73-bet

14-15-bob




text-rar
bart
lsa
LSA - Latent Semantic Analysis

TextRank
LexRank

Luhn
Gensim
BART Transformers


text summarizer api:

	https://textgears.com/api#languages

	key:	DCPPfV4fxo0eyMKv



 https://github.com/Uberi/speech_recognition#readme


 rev.ai